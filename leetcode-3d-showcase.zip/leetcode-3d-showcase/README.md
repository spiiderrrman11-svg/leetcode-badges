# LeetCode 3D Badge Showcase

A small GitHub Pages site featuring four LeetCode achievement badges in a continuously rotating 3D carousel.

## Publish with GitHub Pages
1. Create a new public repository, for example `leetcode-badges`.
2. Upload `index.html` and the complete `assets` folder from this project.
3. Open **Settings → Pages** in the repository.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select **main** and **/(root)**, then save.
6. After GitHub publishes the site, copy the Pages URL into your GitHub profile README.

The carousel uses HTML and CSS only. GitHub README files do not run custom CSS animations, so publish this as a GitHub Pages site and link to it from your README.
